<?php

// Required if your environment does not handle autoloading
require_once 'twilio-php-master/src/Twilio/autoload.php';

use Twilio\Rest\Client;

// Your Account SID and Auth Token from twilio.com/console
$sid = 'ACd33bc6f66cebcc18420410350f26b01e';
$token = '82fca82c473d25924d0a240576d985ea';
$client = new Client($sid, $token);

// Use the client to do fun stuff like send text messages!
$client->messages->create(
    // the number you'd like to send the message to
    '+27731526956',
    [
        // A Twilio phone number you purchased at twilio.com/console
        'from' => '+16073006928',
        // the body of the text message you'd like to send
        'body' => 'Hey Client! this is a test message for your woocommerce plugin from twillio!'
    ]
);
